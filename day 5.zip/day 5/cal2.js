var input_box1 = document.getElementById("no1");
var input_box2 = document.getElementById("arth");
var input_box3 = document.getElementById("no2");
var input_box4 = document.getElementById("ans");

function userClickButton(input){

    if(input_box1.value.length == 0) 
    {
      
    input_box1.value=input;

        
    }
    else
    {
        input_box3.value = input;
    }

}

function myfunction(input){
    input_box2.value=input;
}

function calculateValueCalc2()
{
    var ans = input_box1.value + input_box2.value + input_box3.value;
    var result1 = eval(ans);
    document.getElementById("ans").value = result1;
}

function clearData2() {
    input_box1.value="";
    input_box2.value="";
    input_box3.value="";
    input_box4.value="";
}