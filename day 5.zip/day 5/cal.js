var input_box = document.getElementById("calculation");

function DigitDisplay(input){
    var oldInput = input_box.value;
    var newInput = oldInput + "" + input;
    input_box.value = newInput;
}

function calculateValue()
{
    var input = input_box.value;
    var result = eval(input);
    input_box.value = result;
}

function clearData() {
    input_box.value="";
}