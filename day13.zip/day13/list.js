// add to do list script
var i = 1;
$(document).on('click', '.add-todo', function () {
    var todoInputData1 = $('#text1').val();
    console.log(todoInputData1)
    var todoInputData2 = $('#text2').val();
    console.log(todoInputData2)
   // var todoListData = ` <li class='list'> Ingredients: " + todoInputData1 + "  , Unit: KG  , Quantity:" + todoInputData2 + " <button type='button' id = 'del' class='btn btn-danger'>X</button></li>`;
   // console.log(todoListData);


    // add todo list on click button  
    if (($.trim(todoInputData1) == '' && $.trim(todoInputData2) == '')) {
        window.alert("You must enter something!!")
    }
    else {
        $('.todo-list').append("<div class='list-row'>" + i +". " + "   Ingredients: " + todoInputData1 + "  , Unit: KG  , Quantity:" + todoInputData2 +" <span style='margin: 20px'></span> "+"<button type='button' id = 'del' class='btn btn-danger'>X</button></div><br>");
        i++;
        $("#text1").val("");
        $("#text2").val("");
    }

});

//$(document).ready(() => {
    $("#photo").change(function () {
        const file = this.files[0];
        if (file) {
            let reader = new FileReader();
            reader.onload = function (event) {
                $("#imgPreview")
                  .attr("src", event.target.result);
            };
            reader.readAsDataURL(file);
        }
    
    });



//remove todo list script
$(document).on('click', '#del', function () {
    $(this).closest('.list-row').remove();
})